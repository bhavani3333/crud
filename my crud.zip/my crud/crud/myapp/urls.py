from django.urls import path

from .views import PostDetailsView, GetDetailsView, UpdatePharmacyView, DeletePharmacyView

urlpatterns = [
    path('post_data/', PostDetailsView.as_view(), name="post_student"),
    path('get_data/<pk>/', GetDetailsView.as_view(), name="view_student"),
    path('update_data/<pk>/', UpdatePharmacyView.as_view(), name="update_student"),
    path('delete_data/<pk>/', DeletePharmacyView.as_view(), name="delete_student"),

    ]