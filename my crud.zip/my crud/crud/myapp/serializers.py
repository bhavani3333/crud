from rest_framework import serializers

from .models import Student


class StudentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Student
        fields = '__all__'

class GetStudentSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField()

    class Meta:
        model = Student
        fields = '__all__'

class UpdateStudentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Student
        fields = '__all__'

        def validate_email(self, value):
            if Student.objects.filter(email=value).exists():
                raise serializers.ValidationError("This email already exists!.")
            return value


class DeleteStudentSerializer(serializers.ModelSerializer):
    id=serializers.IntegerField()

    class Meta:
        model = Student
        fields = ['id']