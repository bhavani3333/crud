from django.db import models

# Create your models here.
class Student(models.Model):
    id = models.IntegerField(db_column='id',primary_key = True)
    name = models.CharField(db_column='name',max_length=80)
    phonenumber = models.CharField(db_column='phone_number',max_length=10)
    email = models.EmailField(db_column='email')
    department = models.CharField(db_column='department',max_length=50)
    address = models.CharField(db_column='address',max_length=100)

    class Meta:
        db_table='student'