from django.shortcuts import render

# Create your views here.
from rest_framework import generics, status
from rest_framework.parsers import JSONParser
from rest_framework.response import Response

from .models import Student
from .serializers import GetStudentSerializer, StudentSerializer, UpdateStudentSerializer, DeleteStudentSerializer


class PostDetailsView(generics.GenericAPIView, ):
    serializer_class = StudentSerializer

    def post(self, request):
        data = {}
        user_data_request = JSONParser().parse(request)
        serializer = self.serializer_class(data=user_data_request)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            data["responseCode"] = status.HTTP_200_OK
            data["typeCode"] = status.HTTP_200_OK
            data['message'] = "Successfully posted"
            data['userData'] = serializer.data
            return Response(data=data)
        else:
            data["responseCode"] = status.HTTP_400_BAD_REQUEST
            data["typeCode"] = status.HTTP_400_BAD_REQUEST
            data['message'] = "invalid data"
            return Response(data=data)



class GetDetailsView(generics.RetrieveAPIView ):
    serializer_class = GetStudentSerializer

    def get(self,request,pk):
        data = {}
        studentData = Student.objects.filter(id=pk)
        if studentData:

            serializer = GetStudentSerializer(data=studentData,many=True)
            serializer.is_valid()
            data["responseCode"] = status.HTTP_200_OK
            data["typeCode"] = status.HTTP_200_OK
            data['message'] = "Success"
            data['userData'] = serializer.data
            return Response(data=data)
        else:
            data["responseCode"] = status.HTTP_400_BAD_REQUEST
            data["typeCode"] = status.HTTP_400_BAD_REQUEST
            data['message'] = "id not existing"
            return Response(data=data)


class UpdatePharmacyView(generics.UpdateAPIView ):
    serializer_class = UpdateStudentSerializer
    queryset = Student.objects.all()


class DeletePharmacyView(generics.DestroyAPIView):
    serializer_class = DeleteStudentSerializer

    def delete(self, request,pk):
        data = {}
        student = Student.objects.filter(id=pk)

        if student:
            student.delete()
            data["responseCode"] = status.HTTP_200_OK
            data["typeCode"] = status.HTTP_200_OK
            data['message'] = "deleted Successfully"
            return Response(data=data)

        else:
            data["responseCode"] = status.HTTP_400_BAD_REQUEST
            data["typeCode"] = status.HTTP_400_BAD_REQUEST
            data['message'] = "id not existing"
            return Response(data=data)
